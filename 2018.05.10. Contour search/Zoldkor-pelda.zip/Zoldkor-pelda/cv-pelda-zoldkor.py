
# Képfeldolgozó sablon program alapján.

# Feladat: a bemeneti képen keressük meg a zöld köröket, karikázzuk be őket és
# írjuk ki középpontjuk koordinátáját és sugarát.


# szokásos importálások
import numpy as np
import cv2
import os
import tkinter as tk
from tkinter import filedialog


#------- beállítások
# os.chdir("...........")   # ha szükséges....

debug=False      # ha be van kapcsolva (True), mindenfélét kiír menet közben


in_file="teszt-zoldkor.png"   # beolvasandó fájl alapértemlezett neve
in_request=True    # True: inkább kérjük be a fájlnevet interaktívan
                   # False: maradjon az előbb megadott fájlnév
in_window=True     # Megjelenítsük-e az eredeti képet ablakban
out_window=True    # Megjelenítsük-e a kimenetet ablakban

#out_file="ki.png"  # kiírandó fájl alapértelmezett neve
out_file="ki-"+in_file  # kimeneti fájlnév
out_request=False  # True: kérdezzük meg a felhasználót a kimeneti fájlról
#-------

root=tk.Tk()
root.withdraw()   # ne látszódjon a root ablak
wdir=os.getcwd()

if in_request:     # bemeneti fájl nevét bekérő ablak megnyitása, ha kell
	in_file=filedialog.askopenfilename(parent=root,title="Bemeneti fájl",initialdir=wdir)
in_img=cv2.imread(in_file)  # beolvasás, mindenképp ezen a néven

#------------------------
# FELDOLGOZÁS
print("Feldolgozás indul...")

####################### 1. lépés: előtér-háttér szétválasztás.
# Előtér= zöldnek nevezhető pixelek.

# térjünk át HSV-re:
im_HSV=cv2.cvtColor(in_img,cv2.COLOR_BGR2HSV)  #
# zöld: 80>=H>=40 , mivel H értékének a felét számolja az opencv
# és még legyen egy kicsit élénk is (S>50), hogy a zajt csökkentsük!
mask_zold=(im_HSV[:,:,0]<=80) & (im_HSV[:,:,0]>=40)  & (im_HSV[:,:,1]>50)
# True-False -ról uint8-ra konvertálás:
mask_zold=mask_zold.astype(np.uint8)

if debug: # ha debuggolunk, akkor kiírjuk a maszkot egy képfájlba
	cv2.imwrite("debug-mask_zold.png",mask_zold*255)

####################### 2. lépés: kontúr keresés.
	
conts, hier=cv2.findContours(mask_zold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
# Figyelem! Régebbi OpenCV verziókban a cv2.findContours-nak 3 kimenete volt.
# Ha ezzel kapcsolatos hibát kapunk, akkor kezdjük így az előző sort:
# imgtmp, conts, hier=cv2.findContours(.....

if debug: # debuggoláskor hasznos információ:
        print("Össz kontúrok száma: %d"%(len(conts)))

####################### 3. lépés: kontúrok elemzése.

# kimeneti kép alapja: a bemeneti halványítva
out_img=in_img.copy() 
out_img//=3

# most végigmegyünk a kontúrok listáján:
# conts: ezt adta vissza a cv2.findContours()
for cont in conts:
        # cont: sorra felveszi a conts lista elemeit
        area=cv2.contourArea(cont)  # mennyi a területe?
        if debug:
                print("ter=%d"%(area))
        if (area<3):   # túl kicsivel nem foglalkozunk (zaj)
                continue  # continue= a ciklus első elemére ugrik
        perim=cv2.arcLength(cont, True)   # mennyi a kerülete?

        # körülírt kör meghatározása
        center, r=cv2.minEnclosingCircle(cont) # ez kiszámolja, de float-ban adja ki
        # egészre átváltott koordináták:
        ic=(int(center[0]), int(center[1]))
        ir=int(r)

        # körszerűségi mérőszám: körre circ=1,
        #       minél inkább eltér a körtől, annál kisebb
        circ=4.0*np.pi*area/perim**2  

        if debug:  # ha debuggolunk, írjuk ki a körszerűségi számokat
                cv2.putText(out_img,"%4.3f" % circ,(ic[0]-8,ic[1]), cv2.FONT_HERSHEY_PLAIN,1.0,(0,0,255))

        if circ<0.85:   # ha nem elég körszerű, akkor ugrás
                continue
        
        # ha idáig eljutunk, akkor van körünk!

        # most kirajzoljuk a kört
        cv2.circle(out_img, ic, ir, (0,0,255))
        # ... és kiírjuk a paramétereit:
        print("xc=%6.2f, yc=%6.2f, r=%6.2f"%(ic[0], ic[1], ir))

	
# Önálló feladatok:
#   - csak a bizonyos sugár alatti köröket listázzuk
#   - a lila köröket keressük
#   - tegyük áttekinthetőbbé a programot
#   - a maszkból szűrjük ki a kicsi pöttyöket pl. median filterrel
#   - ....

print("Feldolgozás vége.")

#------------------------
if in_window: 
	cv2.namedWindow("Bemenet")   # ablak megnyitása, ha kell
	cv2.imshow("Bemenet", in_img)

if out_window:
	cv2.namedWindow("Kimenet")   # ablak megnyitása, ha kell
	cv2.imshow("Kimenet",out_img)

if in_window or out_window:
	cv2.waitKey(0)               # ha megjelenítettünk ablakot, akkor várunk 
#------------------------

if out_request:       # kiírás helyének bekérése, ha kell
	out_file=filedialog.asksaveasfilename(parent=root,title="Kimeneti fájl",initialdir=wdir)

cv2.imwrite(out_file,out_img) # kiírás

#------------------------

root.destroy()  # menj innen, te gyökér!
if in_window or out_window: 
	cv2.destroyAllWindows()  # ne legyen huzat....
